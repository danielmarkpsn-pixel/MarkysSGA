<?php

declare(strict_types=1);

/*
 * This file is part of the NovoSGA project.
 *
 * (c) Rogerio Lino <rogeriolino@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace App\Form;

use Doctrine\ORM\EntityRepository;
use App\Entity\Servico;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\Range;

class ServicoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $entity = $options['data'];

        $builder
            ->add('nome', TextType::class, [
                'label' => 'label.name',
                'constraints' => [
                    new Length(min: 1, max: 50),
                ],
            ])
            ->add('descricao', TextareaType::class, [
                'label' => 'label.description',
                'attr' => [
                    'rows' => 4,
                ],
                'constraints' => [
                    new Length(min: 1, max: 250),
                ],
            ])
            ->add('ativo', CheckboxType::class, [
                'label' => 'label.enabled',
                'required' => false,
            ])
            ->add('peso', IntegerType::class, [
                'label' => 'label.weight',
                'constraints' => [
                    new Range(min: 0),
                ],
            ])
        ;

        if (!$entity->isMestre() || count($entity->getSubservicos()) === 0) {
            $builder->add('mestre', EntityType::class, [
                'label' => 'admin.services.field.parent',
                'class' => Servico::class,
                'placeholder' => 'Nenhum',
                'required' => false,
                'query_builder' => function (EntityRepository $er) use ($entity) {
                    $qb = $er
                        ->createQueryBuilder('e')
                        ->where('e.mestre IS NULL')
                        ->andWhere('e.deletedAt IS NULL');

                    if ($entity->getId()) {
                        $qb
                            ->andWhere('e != :entity')
                            ->setParameter('entity', $entity);
                    }

                    return $qb;
                }
            ]);
        }
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Servico::class
        ]);
    }
}
